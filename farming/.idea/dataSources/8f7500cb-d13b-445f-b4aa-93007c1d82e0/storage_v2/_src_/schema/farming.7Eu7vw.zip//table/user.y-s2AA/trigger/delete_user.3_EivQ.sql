create definer = root@localhost trigger delete_user
    after delete
    on user
    for each row
begin  
    if OLD.status=3 then    
			delete from tb_reporter
        where user_id = OLD.id;
    end if;
				if OLD.status=1 then    
			delete from tb_expert
        where user_id = OLD.id;
		end if;
		if OLD.status=0 then    
			delete from tb_farmer
        where user_id = OLD.id;
		end if;
end;

