create definer = root@localhost trigger status
    after insert
    on user
    for each row
begin  
		if NEW.status=1 then    
			insert into tb_expert(user_id,address)  
        values(NEW.id,NEW.name); 
		end if;
    if NEW.status=3 then    
			insert into tb_reporter(user_id)  
        values(NEW.id); 
    end if;  
		if NEW.status=0 then    
			insert into tb_farmer(user_id)  
        values(NEW.id); 
		end if;
end;

