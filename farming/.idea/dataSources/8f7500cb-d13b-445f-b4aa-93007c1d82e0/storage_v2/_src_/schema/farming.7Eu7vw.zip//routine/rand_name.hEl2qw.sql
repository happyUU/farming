create
    definer = root@localhost function rand_name(n int) returns varchar(255)
BEGIN
declare chars_str varchar(52) default '赵天昕影郝悦孙泊秀琪可茜周泽科柯缇吴城珀张新章郭国果填添一艺宜移怡译王心意懿彦李希嬴舞宁格欣武';
declare return_str varchar(255) default '';
declare i int default 0;
while i<n do
set return_str=concat(return_str,substring(chars_str,floor(1+rand()*52),1));
set i=i+1;
end while;
return return_str;
END;

