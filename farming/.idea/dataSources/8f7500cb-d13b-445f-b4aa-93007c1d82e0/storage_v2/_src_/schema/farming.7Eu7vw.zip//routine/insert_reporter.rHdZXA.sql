create
    definer = root@localhost procedure insert_reporter(IN start int(10), IN max_num int(10))
BEGIN
declare i int default 0;
set autocommit=0;
repeat
set i=i+1;
insert into tb_user (name,password,telephone,status) values(rand_name(3),rand_password(20),rand_num(),3);
until i=max_num
end repeat;
commit;
END;

