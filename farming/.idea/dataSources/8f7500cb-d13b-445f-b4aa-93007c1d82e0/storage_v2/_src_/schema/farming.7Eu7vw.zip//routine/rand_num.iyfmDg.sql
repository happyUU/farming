create
    definer = root@localhost function rand_num() returns int
BEGIN
declare i int default 0;
set i=floor(8000000+rand()*800000);
return i;
END;

