create definer = root@localhost view find_news as
select `n`.`id`           AS `id`,
       `n`.`news_title`   AS `news_title`,
       `n`.`news_author`  AS `news_author`,
       `n`.`news_time`    AS `news_time`,
       `n`.`news_content` AS `news_content`,
       `n`.`news_image`   AS `news_image`,
       `u`.`name`         AS `NAME`,
       `r`.`office`       AS `office`
from ((`farming`.`tb_news` `n` join `farming`.`tb_user` `u`)
         join `farming`.`tb_reporter` `r`)
where ((`n`.`news_author` = `u`.`id`) and (`r`.`user_id` = `u`.`id`));

-- comment on view find_news not supported: View 'farming.find_news' references invalid table(s) or column(s) or function(s) or definer/invoker of view lack rights to use them

